import os
import streamlit as st
import tiktoken
from loguru import logger

from langchain.chains import ConversationalRetrievalChain
from langchain.chat_models import ChatOpenAI

from langchain.document_loaders import PyPDFLoader
from langchain.document_loaders import Docx2txtLoader
from langchain.document_loaders import UnstructuredPowerPointLoader

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings

from langchain.memory import ConversationBufferMemory
from langchain.vectorstores import FAISS

from langchain.callbacks import get_openai_callback
from langchain.memory import StreamlitChatMessageHistory
from llama_cpp import Llama
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch

from Flair import KeywordExtractor
from RAG_generate import RagGenerator
import re
import base64
import time



## 전체적으로 사용되는 부분 (RAG를 구현하기 위해서 VectDB를 만드는 과정) ##

# API 키 직접 지정
openai_api_key = "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"  

# DB 처리를 위한 사전 코드 정의 
# (1)
def tiktoken_len(text):
    tokenizer = tiktoken.get_encoding("cl100k_base")
    tokens = tokenizer.encode(text)
    return len(tokens)
# (2) 파일 형식에 따라 적절한 문서 로더를 사용하여 텍스트 데이터를 추출
def get_text(docs):
    doc_list = []
    
    for doc in docs:
        file_name = doc.name
        with open(file_name, "wb") as file:
            file.write(doc.getvalue())
            logger.info(f"Uploaded {file_name}")
        if '.pdf' in doc.name:
            loader = PyPDFLoader(file_name)
            documents = loader.load_and_split()
        elif '.docx' in doc.name:
            loader = Docx2txtLoader(file_name)
            documents = loader.load_and_split()
        elif '.pptx' in doc.name:
            loader = UnstructuredPowerPointLoader(file_name)
            documents = loader.load_and_split()

        doc_list.extend(documents)
    return doc_list

# (3) local에서 불러오는 코드 // 각 문서를 분할하여 모든 텍스트를 리스트로 반환
def load_local_documents(folder_path):
    doc_list = []
    for file_name in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file_name)
        if file_name.endswith(".pdf"):
            loader = PyPDFLoader(file_path)
        elif file_name.endswith(".docx"):
            loader = Docx2txtLoader(file_path)
        elif file_name.endswith(".pptx"):
            loader = UnstructuredPowerPointLoader(file_path)
        else:
            continue
        documents = loader.load_and_split()
        doc_list.extend(documents)
        logger.info(f"Loaded {file_name}")
    return doc_list
# (4) 문서를 작은 단위로 나누는 코드 
def get_text_chunks(text):
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=900,
        chunk_overlap=100,
        length_function=tiktoken_len
    )
    chunks = text_splitter.split_documents(text)
    return chunks
# (5) 벡터 데이터베이스를 생성 -> CPU환경에서 돌아갈 수 있게 해둠
def get_vectorstore(text_chunks):
    embeddings = HuggingFaceEmbeddings(
        model_name="jhgan/ko-sroberta-multitask",
        model_kwargs={'device': 'cpu'},
        encode_kwargs={'normalize_embeddings': True}
    )  
    vectordb = FAISS.from_documents(text_chunks, embeddings)
    return vectordb


## 소제목 생성기에 사용될 모델 ##
llm = Llama.from_pretrained(
    repo_id="Kimsangwook/llama3_bllossom_gguf_q5",
    filename="llama3_bllossom_gguf_q5.gguf",
)
## subtask - 소제목 생성기 관련 code ##
def generate_subtitle_with_llama(text):
    PROMPT = "System: 입력받은 자기소개서에 대해서 인상 깊은 소제목을 한줄로 생성해줘."
    messages = [
        {"role": "system", "content": PROMPT},
        {"role": "user", "content": text}
    ]
    
    # Llama 모델을 사용하여 소제목 생성
    response = llm.create_chat_completion(messages=messages)
    # 답변 텍스트만 추출
    answer = response['choices'][0]['message']['content']
    return answer.split("\n")[0]


## subtask - 챗봇에 사용되는 code ##
def get_conversation_chain(vetorestore, openai_api_key):
    llm = ChatOpenAI(openai_api_key=openai_api_key, model_name='gpt-3.5-turbo', temperature=0)
    conversation_chain = ConversationalRetrievalChain.from_llm(
        llm=llm, 
        chain_type="stuff", 
        retriever=vetorestore.as_retriever(search_type='mmr', vervose=True), 
        memory=ConversationBufferMemory(memory_key='chat_history', return_messages=True, output_key='answer'),
        get_chat_history=lambda h: h,
        return_source_documents=True,
        verbose=True
    )
    return conversation_chain

def message_template(keyword, job_field, doc):
    return [ {"role": "system",
              "content": f"""당신은 {job_field}와 {keyword} 안에 있는 각 키워드, 각 키워드와 관련된 자료 {doc}를 바탕으로,
                             각 키워드별로 비유 문장을 생성하는 전문가입니다.
                             {keyword}를 강조하는 문장을 비유 표현을 사용하여 생성해주세요.
                             {keyword}로 1개씩 총 5개의 문장을 생성해주세요."""},
              {"role": "user", "content": f"{job_field} 직무와 {doc}을 바탕으로 비유 문장을 생성해주세요: "},
              {"role": "user", "content": f"각 {keyword}가 포함된 자기소개 문장을 비유 표현을 사용하여 '저의 {keyword} 역량은 ~입니다.' 형식으로 작성해 주세요."}
            ]

def main():
    st.set_page_config(page_title="Text2Metaphor", page_icon=":books:")


    st.markdown("<h1 style='font-size: 120px;'>WHORYOU?</h1>", unsafe_allow_html= True)
    st.markdown("<h2 style='font-size: 40px;'>ALL IN ONE - 취업 준비 솔루션</h2>", unsafe_allow_html= True)
    # 각 직무군에 대한 로컬 경로 사전 설정
    job_paths = {
        "ICT": "ICT",
        "디자인": "디자인",
        "마케팅": "path/to/marketing_documents",
        "개발": "path/to/dev_documents",
        "운영": "path/to/operations_documents",
        "영업": "path/to/sales_documents",
        "인사": "path/to/hr_documents",
    }
        # 'selected_options'이 초기화되지 않았을 때의 기본값 설정
    if 'selected_options' not in st.session_state:
        st.session_state.selected_options = []
            # URL을 사용하여 배경 이미지 설정
        image_url = "https://i.imgur.com/jgazRgN.png"  # 사용하고자 하는 이미지의 URL로 변경

        st.markdown(
        f"""
        <style>
        .stApp {{
            background-image: url("{image_url}");
            background-size: 30%;  /* 이미지 크기를 50%로 조정 */
            background-position: center 80%; 
            background-repeat: no-repeat;
        }}
        </style>
        """,
        unsafe_allow_html=True
        )
    # 기능 선택
    options = st.multiselect("원하는 기능을 모두 선택하세요", ["비유적 표현 생성기", "소제목 생성기","챗봇"], default=st.session_state.selected_options)
    st.session_state.selected_options = options

    if "비유적 표현 생성기" in st.session_state.selected_options:
        st.write("")
        st.write("")
        st.subheader("Generator_자기소개 : 비유적 표현 생성기.")
        job_field = st.sidebar.selectbox("직무군 선택", list(job_paths.keys()))
        
        # 직무가 선택되면 추가 입력을 받는다.
        if job_field:
            # 핵심역량과 자기소개서 내용을 입력 받는다.
            core_competency = st.text_input("핵심역량을 입력하세요", "예: 커뮤니케이션, 리더십 등")
            introduction_text = st.text_area("자기소개서 내용을 입력하세요", "여기에 자기소개서 내용을 입력하세요.", height=250)
            
            # 입력이 모두 완료되었다면 문서 처리를 시작한다.
            if st.button("비유적 표현 생성"):
                # 격려 문구 리스트
                motivational_quotes = [
    "No Pain!! No Gain!!",
    "당신이 할 수 있다고 믿든 할 수 없다고 믿든 믿는 대로 될 것이다.",
    "스스로를 믿으세요!",
    "성공은 포기하지 않는 사람에게 온다.",
    "끈기는 모든 것을 이겨냅니다.",
    "사막이 아름다운 것은 어딘가에 샘이 숨겨져 있기 때문이다.",
    "나 자신에 대한 자신감을 잃으면 온 세상이 나의 적이 된다.",
    "절대 어제를 후회하지 마라. 인생은 오늘의 나 안에 있고 내일은 스스로 만드는 것이다.",
    "삶이 있는 한 희망은 있다.",
    "인생에서 가장 슬픈 세 가지. 할 수 있었는데, 해야 했는데, 해야만 했는데.",
    "같은 실수를 두려워하되 새로운 실수를 두려워하지 마라. 실수는 곧 경험이다.",
    "진정으로 웃으려면 고통을 참아야하며, 나아가 고통을 즐길 줄 알아야 한다.",
    "오늘은 당신의 남은 인생 중, 첫 번째 날이다.",
    "인생은 곱셈이다. 어떤 기회가 와도 내가 제로면 아무런 의미가 없다.",
    "실패란 넘어지는 것이 아니라, 넘어진 자리에 머무는 것이다.",
    "1퍼센트의 가능성, 그것이 나의 길이다.",
    "이 또한 지나가리라.",
    "오랫동안 꿈을 그리는 사람은 마침내 그 꿈을 닮아간다.",
    "삶이란 결코 쉽게 풀리는 숙제가 아니다.",
    "포기하는 순간, 게임은 끝난다.",
    "성공이란 열정을 잃지 않고 실패를 거듭할 수 있는 능력이다.",
    "행동이 반드시 행복을 가져다 주지는 않지만, 행동 없이는 행복이 없다.",
    "성공은 최선을 다한 결과이지, 성공하기 위한 결과가 아니다.",
    "시작하기에 완벽한 순간을 기다리지 마라. 지금이 바로 그 순간이다.",
    "작은 기회로부터 종종 위대한 업적이 시작된다.",
    "누구에게나 내일은 기회다. 아직 쓰여지지 않은 페이지이기 때문이다.",
    "끝날 때까지는 끝난 게 아니다.",
    "어두운 밤이 지나야 밝은 아침이 온다.",
    "어제보다 나은 오늘을 만들기 위해 노력하라.",
    "자신을 믿고 한 걸음씩 나아가라.",
    "변화는 언제나 어렵지만, 그것이 성장으로 가는 길이다.",
    "큰 시련 뒤에는 반드시 큰 축복이 있다.",
    "꿈을 꾸는 자에게 불가능이란 없다.",
    "가장 용기 있는 사람은 꿈을 꾸는 사람이다.",
    "승리는 끝까지 포기하지 않은 자에게 주어진다.",
    "기회는 준비된 자에게만 온다.",
    "실패는 성공으로 가는 과정일 뿐이다.",
    "비록 천천히 가더라도 멈추지만 않는다면 앞서갈 것이다.",
    "자신의 길을 찾으라. 다른 사람이 아닌 당신이 선택한 길을 걷는 것이 중요하다.",
    "무엇을 두려워하는가? 두려움은 그저 생각일 뿐이다.",
    "행복은 성취가 아니라 과정에 있다.",
    "모든 고통은 당신을 더욱 강하게 만든다.",
    "자신이 옳다고 믿는 일을 하라. 누군가는 항상 그것에 대해 비판할 것이다.",
    "세상은 당신이 무엇을 하느냐에 따라 달라진다.",
    "도전하지 않으면 아무것도 얻을 수 없다.",
    "마음이 가는 대로 하라. 그것이 올바른 길일 것이다.",
    "불가능은 아무것도 아니다.",
    "지금 이 순간이 당신의 미래를 만드는 시간이다.",
    "가장 큰 위험은 위험을 감수하지 않는 것이다.",
    "작은 일이라도 꾸준히 하면 큰 성과를 얻을 수 있다.",
    "꿈을 이루기 위해 필요한 것은 멀리 있는 것이 아니다. 바로 당신 안에 있다.",
    "위대한 일은 하나의 작은 발걸음에서 시작된다.",
    "스스로가 하고자 하는 일을 믿어라. 그 신념이 당신을 성공으로 이끈다.",
    "모든 일에는 이유가 있다. 그 이유는 결국 당신에게 도움이 될 것이다."
]


                message_placeholder = st.empty()
                
                # 로딩 문구 표시
                for quote in motivational_quotes:
                    message_placeholder.text(quote)
                    time.sleep(3)  # 3초 동안 해당 문구 표시

                # 키워드 추출 및 문서 생성 코드
                keyword_extractor = KeywordExtractor()
                rag_generator = RagGenerator(openai_api_key, job_field, "C:/김상욱/conference/streamlit")

                # 키워드 추출
                keywords = keyword_extractor.extract_keywords(introduction_text)
                if keywords:  # 키워드가 있는지 확인
                    top_related_keywords = keyword_extractor.final_top5_keywords(core_competency, keywords)
                else:
                    top_related_keywords = []
                    st.write("추출된 키워드가 없습니다.")

                # 로딩 문구 지우기
                message_placeholder.empty()
                
                # 비유적 표현 생성 및 출력
                for keyword, _ in top_related_keywords:
                    doc = rag_generator.retrieve_documents(keyword)
                    prompt = message_template(keyword, job_field, doc)
                    sentence = rag_generator.generate_sentence(prompt)
    
    # 강조된 박스 형태로 출력
                    st.markdown(
                        f"""
                        <div style="
                            border: 1px solid #4CAF50;
                            padding: 10px;
                            border-radius: 5px;
                            background-color: #f9f9f9;
                            margin-top: 10px;">
                            <strong style="color: #388E3C;">{keyword}:</strong> {sentence}
                            </div>
                            """,
                        unsafe_allow_html=True
                                )


        # 컴포넌트 간 간격 추가
        st.write("")
        st.write("")
        st.write("")
        st.write("")
        st.write("")
        st.write("")

    if "소제목 생성기" in options:
        st.write("")
        st.write("")
        st.subheader("Generator_자소서 : 소제목 생성")
        user_input = st.text_area("자기소개서 입력:", "여기에 자기소개서 내용을 입력하세요.")
        if st.button("소제목 생성"):
            if user_input:
                # 문구 리스트
                motivational_quotes = [
    "오랫동안 꿈을 그리는 사람은 마침내 그 꿈을 닮아간다.",
    "삶이란 결코 쉽게 풀리는 숙제가 아니다.",
    "포기하는 순간, 게임은 끝난다.",
    "성공이란 열정을 잃지 않고 실패를 거듭할 수 있는 능력이다.",
    "행동이 반드시 행복을 가져다 주지는 않지만, 행동 없이는 행복이 없다.",
    "성공은 최선을 다한 결과이지, 성공하기 위한 결과가 아니다.",
    "시작하기에 완벽한 순간을 기다리지 마라. 지금이 바로 그 순간이다.",
    "작은 기회로부터 종종 위대한 업적이 시작된다.",
    "누구에게나 내일은 기회다. 아직 쓰여지지 않은 페이지이기 때문이다.",
    "끝날 때까지는 끝난 게 아니다.",
    "어두운 밤이 지나야 밝은 아침이 온다.",
    "어제보다 나은 오늘을 만들기 위해 노력하라.",
    "자신을 믿고 한 걸음씩 나아가라.",
    "변화는 언제나 어렵지만, 그것이 성장으로 가는 길이다.",
    "큰 시련 뒤에는 반드시 큰 축복이 있다.",
    "꿈을 꾸는 자에게 불가능이란 없다.",
    "가장 용기 있는 사람은 꿈을 꾸는 사람이다.",
    "승리는 끝까지 포기하지 않은 자에게 주어진다.",
    "기회는 준비된 자에게만 온다.",
    "실패는 성공으로 가는 과정일 뿐이다.",
    "비록 천천히 가더라도 멈추지만 않는다면 앞서갈 것이다.",
    "자신의 길을 찾으라. 다른 사람이 아닌 당신이 선택한 길을 걷는 것이 중요하다.",
    "무엇을 두려워하는가? 두려움은 그저 생각일 뿐이다.",
    "행복은 성취가 아니라 과정에 있다.",
    "모든 고통은 당신을 더욱 강하게 만든다.",
    "자신이 옳다고 믿는 일을 하라. 누군가는 항상 그것에 대해 비판할 것이다.",
    "세상은 당신이 무엇을 하느냐에 따라 달라진다.",
    "도전하지 않으면 아무것도 얻을 수 없다.",
    "마음이 가는 대로 하라. 그것이 올바른 길일 것이다.",
    "불가능은 아무것도 아니다.",
    "지금 이 순간이 당신의 미래를 만드는 시간이다.",
    "가장 큰 위험은 위험을 감수하지 않는 것이다.",
    "작은 일이라도 꾸준히 하면 큰 성과를 얻을 수 있다.",
    "꿈을 이루기 위해 필요한 것은 멀리 있는 것이 아니다. 바로 당신 안에 있다.",
    "위대한 일은 하나의 작은 발걸음에서 시작된다.",
    "스스로가 하고자 하는 일을 믿어라. 그 신념이 당신을 성공으로 이끈다.",
    "모든 일에는 이유가 있다. 그 이유는 결국 당신에게 도움이 될 것이다."
]
                

                # spinner 공간을 비워서 동적 업데이트 설정
                message_placeholder = st.empty()
                try:
                    for quote in motivational_quotes:
                        message_placeholder.text(quote)
                        time.sleep(10)  # 3초 동안 해당 문구 표시
                        
                    # Llama 모델을 사용하여 소제목 생성
                    subtitle = generate_subtitle_with_llama(user_input)
                    st.success("소제목 생성 완료!")
                finally:
                    # 완료 시 문구를 지우기
                    message_placeholder.empty()
                
                st.markdown(
    f"""
    <div style="
        border: 1px solid #ccc;
        padding: 10px;
        border-radius: 5px;
        background-color: #f9f9f9;
        margin-top: 10px;">
        <strong>생성된 소제목:<br/></strong> {subtitle}
    </div>
    """,
    unsafe_allow_html=True
)
            else:
                st.warning("자기소개서 내용을 입력하세요.")

        # 컴포넌트 간 간격 추가
        st.write("")
        st.write("")
        st.write("")
        st.write("")
        st.write("")
        st.write("")
        
    if "챗봇" in options:
        st.write("")
        st.write("")
        st.subheader("Chatbot_Helper :  기업에 대해 궁금해?")
        st.markdown("<h1 style='font-size: 15px;'>기업 맞춤 정보 제공</h1>", unsafe_allow_html= True)
        st.markdown("<h2 style='font-size: 15px;'>기업 관련 문서 (pdf, dox 등)을 입력해서, 원하는 정보만 받아보세요! </h2>", unsafe_allow_html= True)
        st.markdown("<h3 style='font-size: 15px;'>문서를 upload하면 Chatbot이 나타납니다 ^^ </h3>", unsafe_allow_html= True)


        if "conversation" not in st.session_state:
            st.session_state.conversation = None
        if "chat_history" not in st.session_state:
            st.session_state.chat_history = None
        if "processComplete" not in st.session_state:
            st.session_state.processComplete = None

        with st.sidebar:
            uploaded_files = st.file_uploader("파일 업로드", type=['pdf', 'docx'], accept_multiple_files=True)
            process = st.button("Process")
        
        if process:
            files_text = get_text(uploaded_files)
            text_chunks = get_text_chunks(files_text)
            vetorestore = get_vectorstore(text_chunks)

            st.session_state.conversation = get_conversation_chain(vetorestore, openai_api_key)
            st.session_state.processComplete = True

        if st.session_state.processComplete:
            if 'messages' not in st.session_state:
                st.session_state['messages'] = [{"role": "assistant", "content": "기업과 직무 정보를 입력하고, 면접 질문을 생성해보세요!"}]

            for message in st.session_state.messages:
                with st.chat_message(message["role"]):
                    st.markdown(message["content"])

            if query := st.chat_input("질문을 입력해주세요."):
                st.session_state.messages.append({"role": "user", "content": query})
                with st.chat_message("user"):
                    st.markdown(query)

                with st.chat_message("assistant"):
                    chain = st.session_state.conversation
                    with st.spinner("Thinking..."):
                        result = chain({"question": query})
                        response = result['answer']
                        source_documents = result['source_documents']

                        st.markdown(response)
                        with st.expander("참고 문서 확인"):
                            for doc in source_documents:
                                st.markdown(doc.metadata['source'], help=doc.page_content)

                st.session_state.messages.append({"role": "assistant", "content": response})

if __name__ == '__main__':
    main() 
